Music Credits: 

Epic Cinematic Trailer | ELITE
Alex-Productions  44555 

https://www.chosic.com/download-audio/31970/